# Exploring the new notifications in Android N
This is a demo app for implementing improved notifications with direct reply in Android N

# Final result
![alt text](http://i.imgur.com/epBNyB1.png "Final result")

Read more here: https://segunfamisa.com/posts/notifications-direct-reply-android-nougat
